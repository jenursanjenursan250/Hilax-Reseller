"""Offline test: runs the credit system against a fake 3x-ui panel. No Telegram or real panel needed.
Run from the project folder:  python tests/test_flow.py
"""
import json
import os
import sys
import tempfile
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

CLIENTS = {}          # email -> client dict
FAIL_NEXT_ADD = [False]
LOGINS = [0]


class Fake(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, obj, code=200, cookie=False):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        if cookie:
            self.send_header("Set-Cookie", "3x-ui=ok; Path=/")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _form(self):
        n = int(self.headers.get("Content-Length", 0))
        return {k: v[0] for k, v in urllib.parse.parse_qs(self.rfile.read(n).decode()).items()}

    def _authed(self):
        return "3x-ui=ok" in (self.headers.get("Cookie") or "")

    def do_POST(self):
        form = self._form()
        if self.path == "/login":
            LOGINS[0] += 1
            ok = form.get("username") == "admin" and form.get("password") == "pw"
            return self._send({"success": ok, "msg": "ok" if ok else "wrong user"}, cookie=ok)
        if not self._authed():
            return self._send({}, 404)
        if self.path == "/panel/api/inbounds/addClient":
            if FAIL_NEXT_ADD[0]:
                FAIL_NEXT_ADD[0] = False
                return self._send({"success": False, "msg": "boom"})
            c = json.loads(form["settings"])["clients"][0]
            c["_inbound"] = form["id"]
            CLIENTS[c["email"]] = c
            return self._send({"success": True})
        if self.path.startswith("/panel/api/inbounds/updateClient/"):
            c = json.loads(form["settings"])["clients"][0]
            CLIENTS[c["email"]] = c
            return self._send({"success": True})
        if "/delClient/" in self.path:
            uid = self.path.rsplit("/", 1)[1]
            for e, c in list(CLIENTS.items()):
                if c["id"] == uid:
                    del CLIENTS[e]
                    return self._send({"success": True})
            return self._send({"success": False, "msg": "client not found"})
        self._send({}, 404)

    def do_GET(self):
        if not self._authed():
            return self._send({}, 404)
        if self.path.startswith("/panel/api/inbounds/get/"):
            stats = [{"email": e, "up": 1 * 1024 ** 3, "down": 1 * 1024 ** 3,
                      "total": c["totalGB"], "enable": True} for e, c in CLIENTS.items()]
            return self._send({"success": True, "obj": {"clientStats": stats}})
        self._send({}, 404)


srv = HTTPServer(("127.0.0.1", 0), Fake)
threading.Thread(target=srv.serve_forever, daemon=True).start()

os.environ.update({
    "BOT_TOKEN": "1:x", "ADMIN_IDS": "1", "XUI_URL": f"http://127.0.0.1:{srv.server_port}",
    "XUI_USERNAME": "admin", "XUI_PASSWORD": "pw", "INBOUNDS": "8443:1,443:2,119:3,80:11",
    "SUB_URL_BASE": "https://example.com/sub/", "REFUND_UNUSED_ON_DELETE": "true",
    "DB_PATH": os.path.join(tempfile.mkdtemp(), "t.db"),
})

import db            # noqa: E402
import service       # noqa: E402
from xui import XUIError, GB  # noqa: E402

db.init()
db.add_reseller(42, "bob")
assert db.credit(42, 100, "test") == 100

# create: deducts, creates on panel with correct bytes
r = service.create_client(42, "alice", 10, 30, 2)
assert r["balance"] == 90 and CLIENTS["r42_alice"]["totalGB"] == 10 * GB
assert CLIENTS["r42_alice"]["_inbound"] == "2" and r["port"] == 443  # port 443 -> inbound 2
r2 = service.create_client(42, "carol", 1, 0, 11)
assert CLIENTS["r42_carol"]["_inbound"] == "11" and r2["port"] == 80
service.delete_client(42, "carol"); db.credit(42, 1, "restore")  # back to 90 for the rest of the test
assert r["link"].startswith("https://example.com/sub/")

# duplicate name, bad name, too big, insufficient balance
for args, text in [(("alice", 1, 30), "already"), (("a b", 1, 30), "Name must"),
                   (("big", 9999, 30), "Maximum"), (("huge", 400, 30), "Not enough")]:
    try:
        service.create_client(42, *args, 1)
        raise SystemExit(f"expected failure for {args}")
    except service.ServiceError as e:
        assert text in str(e), (args, str(e))
assert db.get_reseller(42)["balance_gb"] == 90

try:
    service.create_client(42, "nope", 1, 30, 999)
    raise SystemExit("expected unknown-port failure")
except service.ServiceError as e:
    assert "Unknown port" in str(e)
db.add_reseller(77, "broke")
try:
    service.precheck_create(77, "newbie", 1)
    raise SystemExit("expected no-credit failure")
except service.ServiceError as e:
    assert "no credit" in str(e)

# panel failure -> NOTHING charged, nothing stored
FAIL_NEXT_ADD[0] = True
try:
    service.create_client(42, "bad", 5, 30, 1)
    raise SystemExit("expected XUIError")
except XUIError:
    pass
assert db.get_reseller(42)["balance_gb"] == 90 and db.get_client(42, "bad") is None

# top-up
t = service.topup_client(42, "alice", 5)
assert t["total_gb"] == 15 and t["balance"] == 85 and CLIENTS["r42_alice"]["totalGB"] == 15 * GB

# overview shows usage (2 GB per fake panel)
ov = service.client_overview(42)
assert ov[0]["used_gb"] == 2 and ov[0]["total_gb"] == 15

# delete with refund of unused: 15 total - 2 used = 13
d = service.delete_client(42, "alice")
assert d["refund"] == 13 and d["balance"] == 98 and "r42_alice" not in CLIENTS

# inactive reseller cannot create
db.set_active(42, False)
try:
    service.create_client(42, "zed", 1, 30, 1)
    raise SystemExit("expected failure")
except service.ServiceError:
    pass
db.set_active(42, True)

# expired session: panel starts answering 404 until we re-login automatically
before = LOGINS[0]
service.panel.session.cookies.clear()
service.panel.get_stats(1)
assert LOGINS[0] == before + 1

# wrong password -> clear error
service.panel.password = "nope"
try:
    service.panel.check()
    raise SystemExit("expected login failure")
except XUIError as e:
    assert "login failed" in str(e).lower()

print("ALL TESTS PASSED")
